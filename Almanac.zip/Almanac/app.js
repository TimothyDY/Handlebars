const express = require('express');
const handlebars = require('express-handlebars');

const app = express();

const hbs = handlebars.create({});
hbs.handlebars.registerHelper('add', (a, b) => a + b)

app.engine('handlebars', handlebars.engine());
app.set('view engine', 'handlebars');

app.use(express.static('public'));

app.get('/', (req, res) => {
  res.render('index', {
  });
});

app.get('/plant', (req, res) => {
  res.render('plant', {
    title: "Plants",
  });
});

app.get('/zombie', (req, res) => {
  res.render('zombie', {
    title: "Zombies",
  });
});

app.get('/world', (req, res) => {
  res.render('world', {
    title: "Maps",
  });
});

app.use((req, res) => {
  res.status(404).send('<h1>404, page not found</h1>')
});

const port = 3000;
app.listen(port, () => {
  console.log(`App is running on http://localhost:${port}`);
});
